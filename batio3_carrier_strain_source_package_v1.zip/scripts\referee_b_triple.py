# -*- coding: utf-8 -*-
"""B-block three-term accounting from matched strain stencils.

Inputs (VASP OUTCARs):
  photo_p003, photo_m003      : energy-ranked occupation at c*(1+-0.003)
  neutral_p003, neutral_m003  : neutral at the SAME geometries
  a0n_stress                  : neutral b at the neutral relaxed geometry
                                (A0n loop's stress_1 OUTCAR, c=c_neutral)

Conversions (paper):
  b [eV/strain/8fu] = -V0 * sigma_zz ;  1 A^3 * 1 kbar = 6.241509e-4 eV
  => b = -0.320407 * sigma_zz[kbar]   (V0 = 513.3431 A^3)

Terms:
  d_b_carrier(eta) = b_photo(eta) - b_neutral(eta)
  d_b_direct       = mean over eta = +-0.003   (zero-strain carrier stress at Qn)
  d_b_mediated     = d_b_direct?  NO:
      d_b_mediated = b_neutral(Qn, 0) - b_neutral(Q0, 0)
                   = mean(b_neutral at +-eta) - b_neutral_A0n
  d_b_net          = direct + mediated  (identity check)

Usage: python referee_b_triple.py <stencil_dir> <a0n_stress_OUTCAR_like>
       (defaults assume the cancon campaign paths)
"""
from pathlib import Path
import re
import sys

B_FACT = 0.320407  # eV per strain per 8 f.u. per kbar  (V0=513.3431 A^3)

def sigma_zz(path):
    """Last 'in kB' line -> zz component (kbar)."""
    last = None
    for ln in Path(path).read_text(errors="replace").splitlines():
        if "in kB" in ln:
            last = ln
    if last is None:
        raise RuntimeError(f"no stress in {path}")
    nums = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", last.split("kB", 1)[1])
    # first three numeric = xx, yy, zz
    return float(nums[2])

def b_of(path):
    return -B_FACT * sigma_zz(path)

def main(stencil_dir, a0n_outcar):
    d = Path(stencil_dir)
    bp = [b_of(d / "OUTCAR_photo_p003"), b_of(d / "OUTCAR_photo_m003")]
    bn = [b_of(d / "OUTCAR_neutral_p003"), b_of(d / "OUTCAR_neutral_m003")]
    b_q0 = b_of(a0n_outcar)

    b_photo_qn0 = sum(bp) / 2.0
    b_neutral_qn0 = sum(bn) / 2.0
    d_direct = b_photo_qn0 - b_neutral_qn0
    d_mediated = b_neutral_qn0 - b_q0
    d_net = d_direct + d_mediated

    print("sigma photo  p003/m003 kbar :", [round(s, 5) for s in
          (-bp[0] / B_FACT, -bp[1] / B_FACT)])
    print("sigma neutral p003/m003 kbar:", [round(s, 5) for s in
          (-bn[0] / B_FACT, -bn[1] / B_FACT)])
    print(f"b_photo(Qn,0)   = {b_photo_qn0:+.4f}")
    print(f"b_neutral(Qn,0) = {b_neutral_qn0:+.4f}")
    print(f"b_neutral(Q0,0) = {b_q0:+.4f}   (A0n)")
    print("-" * 46)
    print(f"d_b_direct    = {d_direct:+.4f} eV/strain/8fu")
    print(f"d_b_mediated  = {d_mediated:+.4f} eV/strain/8fu")
    print(f"d_b_net       = {d_net:+.4f} eV/strain/8fu")
    print(f"identity net-direct-mediated = {d_net - d_direct - d_mediated:+.2e}")
    if d_direct * d_mediated < 0 and abs(d_mediated) > abs(d_direct):
        print("SIGN STRUCTURE: opposite signs, |mediated| > |direct|  OK")
    else:
        print("SIGN STRUCTURE: CHECK (unexpected ordering)")

if __name__ == "__main__":
    sd = sys.argv[1] if len(sys.argv) > 1 else (
        r"C:\Users\GM\Desktop\work\batio3_npj_BC_stage\B_er_n010_stencil")
    a0 = sys.argv[2] if len(sys.argv) > 2 else (
        r"C:\Users\GM\Desktop\work\batio3_A_stage_c642\A0n_neutral\stress_1.out")
    main(sd, a0)
