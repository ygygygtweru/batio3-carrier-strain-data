# -*- coding: utf-8 -*-
"""HSE06 FAST sign-check (5-atom BaTiO3). Just the direct-channel sign.

Speed protocol (vs the 75-k 8x8x8 ncl attempt):
  - vasp_std 6.4.2 (not vasp_ncl)
  - KPOINTS 4x4x4 Gamma, ISYM=0  ->  N_k = 64 known a priori
  - NKRED=2  -> Fock sum on 2x2x2 (8 k-points) instead of 64
  - EDIFF=1e-6, NELM=80, PREC=Accurate, ENCUT=520
  - 3 statics only: photo(Qn,c_ref), neutral(Qn,c_ref), neutral(Q0,c_ref)
    canary = the photo run (gates FERWE then supplies sigma_photo)

Report: d_b_direct = b_photo - b_neutral@Qn  (sign only is the point)
"""
from pathlib import Path

OUT = Path(r"C:\Users\GM\Desktop\work\hse06_fast_sign_5atom")
A_LATT = 3.970717405
C_REF = 4.014893018
N_K = 64  # 4x4x4 ISYM=0
NBANDS = 32


def motif(zBa, zTi, zOeq, zOap):
    dTi = ((0.0 - 0.25) * 2 % 1.0, (0.0 - 0.25) * 2 % 1.0, (zTi - zBa) * 2 % 1.0)
    dOap = ((0.0 - 0.25) * 2 % 1.0, (0.0 - 0.25) * 2 % 1.0, (zOap - zBa) * 2 % 1.0)
    dOeq = ((0.25 - 0.25) * 2 % 1.0, (0.0 - 0.25) * 2 % 1.0, (zOeq - zBa) * 2 % 1.0)
    return {
        "Ba": (0.0, 0.0, 0.0),
        "Ti": tuple(round(v, 8) for v in dTi),
        "Oap": tuple(round(v, 8) for v in dOap),
        "Oeq": tuple(round(v, 8) for v in dOeq),
    }


Q0 = motif(0.2581596804885413, 0.0163880888247570, 0.9988350542209702, 0.2427821222447616)
Qn = motif(0.2560288502763015, 0.0119483895373449, 0.0003557068751974, 0.2463113464359523)


def write_poscar(path, coords, comment):
    a, c = A_LATT, C_REF
    lines = [
        comment, "1.0",
        f"  {a:.10f}    0.000000000000000    0.000000000000000",
        f"  0.000000000000000    {a:.10f}    0.000000000000000",
        f"  0.000000000000000    0.000000000000000    {c:.10f}",
        "  Ba   Ti   O", "  1   1   3", "Direct",
    ]
    ox, oy, oz = coords["Oeq"]
    pts = [coords["Ba"], coords["Ti"], coords["Oap"], coords["Oeq"], (oy, ox, oz)]
    for lab, (x, y, z) in zip(["Ba", "Ti", "Oap", "Oeq1", "Oeq2"], pts):
        lines.append(f"  {x:.10f}  {y:.10f}  {z:.10f}   ! {lab}")
    path.write_bytes(("\n".join(lines) + "\n").encode("ascii"))


BLOCK_PHOTO = "18*1.000000 1*0.950000 1*0.050000 12*0.000000"
BLOCK_NEUTRAL = "19*1.000000 13*0.000000"


def incar(tag, block):
    ferwe = " ".join([block] * N_K)
    return f"""SYSTEM = {tag}
ISPIN = 1
PREC = Accurate
ENCUT = 520
NBANDS = {NBANDS}
NELECT = 38.0
ISMEAR = -2
ALGO = Normal
NELM = 80
EDIFF = 1E-6
LREAL = .FALSE.
LASPH = .TRUE.
ISYM = 0
IBRION = -1
NSW = 0
ISTART = 0
ICHARG = 2
LWAVE = .FALSE.
LCHARG = .FALSE.
NWRITE = 2
# HSE06 FAST
LHFCALC = .TRUE.
HFSCREEN = 0.2
AEXX = 0.25
NKRED = 2
FERWE = {ferwe}
"""


KPOINTS = """BaTiO3 5-atom 4x4x4 Gamma ISYM=0 (N_k=64)
0
Gamma
4 4 4
0 0 0
"""

CHAIN = r'''#!/bin/bash
set -u
set -o pipefail
BIN=/home/pfm/vasp.6.4.2/bin/vasp_std
ROOT=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT"
NP=32
export OMP_NUM_THREADS=1
set +u
source /opt/intel/oneapi/setvars.sh >/dev/null 2>&1 || true
set -u
log(){ echo "[$(date +%H:%M:%S)] $*"; }

run_one(){
  local dir=$1
  cd "$ROOT/$dir" || { log "FAIL no $dir"; return 1; }
  cp -f "$ROOT/POTCAR" POTCAR
  # gate: FERWE count == 32*64=2048
  local n=$(python3 -c "
import re
s=open('INCAR').read()
m=re.search(r'FERWE\s*=\s*([^\n]+)',s)
n=0
for t in m.group(1).split():
    n += int(t.split('*')[0]) if '*' in t else 1
print(n)")
  if [ "$n" != "2048" ]; then log "FAIL $dir FERWE=$n !=2048"; return 1; fi
  log "START $dir"
  mpirun -np $NP "$BIN" > vasp.out 2> vasp.err
  [ $? -eq 0 ] || { log "FAIL $dir vasp rc"; return 1; }
  grep -q "General timing" OUTCAR || { log "FAIL $dir no timing"; return 1; }
  grep -q "in kB" OUTCAR || { log "FAIL $dir no stress"; return 1; }
  if [ "$dir" = "photo_Qn" ]; then
    grep -q "1.90000" OUTCAR || grep -q "1.8999" OUTCAR || { log "FAIL occ 1.9"; return 1; }
    grep -q "0.10000" OUTCAR || grep -q "0.0999" OUTCAR || { log "FAIL occ 0.1"; return 1; }
    log "PASS occ 1.9/0.1"
  fi
  grep "in kB" OUTCAR | tail -1 > sigma.txt
  log "PASS $dir $(cat sigma.txt)"
  cd "$ROOT"
  return 0
}

log "=== HSE FAST sign-check ==="
run_one photo_Qn     || { echo CANARY_FAIL > STATUS; exit 1; }
log "canary(photo FERWE) PASS"
run_one neutral_Qn   || { echo FAIL_neutral_Qn > STATUS; exit 1; }
run_one neutral_Q0   || { echo FAIL_neutral_Q0 > STATUS; exit 1; }

python3 - <<'PY'
import re, pathlib
root = pathlib.Path(".")
V0 = 3.970717405**2 * 4.014893018
BF = V0 * 6.241509e-4
def sig(d):
    t = (root/d/"sigma.txt").read_text()
    return float(re.findall(r"[-+]?\d+\.\d+", t.split("kB",1)[1])[2])
bp, bn, b0 = -BF*sig("photo_Qn"), -BF*sig("neutral_Qn"), -BF*sig("neutral_Q0")
direct = bp - bn
mediated = bn - b0
print("sigma photo/neutral/Q0 kbar:", sig("photo_Qn"), sig("neutral_Qn"), sig("neutral_Q0"))
print("d_b_direct   = %+.5f eV/strain/fu" % direct)
print("d_b_mediated = %+.5f eV/strain/fu" % mediated)
print("d_b_net      = %+.5f" % (direct+mediated))
if direct < 0 and mediated > 0:
    open("STATUS","w").write("PASS_SIGN_MATCH\n")
    print("SIGN: direct<0 mediated>0  MATCHES PBE/SCAN")
elif direct < 0:
    open("STATUS","w").write("PASS_DIRECT_SIGN\n")
    print("SIGN: direct<0 OK; mediated=%+.4f" % mediated)
else:
    open("STATUS","w").write("CHECK_SIGNS\n")
    print("SIGN: CHECK direct=%+.4f mediated=%+.4f" % (direct, mediated))
PY
log "done $(cat STATUS 2>/dev/null)"
'''

SLURM = """#!/bin/bash
#SBATCH -J HSE_fast
#SBATCH -p compute
#SBATCH -N 1
#SBATCH -n 32
#SBATCH -t 12:00:00
#SBATCH -o hse_fast_%j.out
#SBATCH -e hse_fast_%j.err
bash run_chain_fast.sh
"""


def main():
    jobs = [
        ("photo_Qn", Qn, "HSE06 photo n=0.10 Qn c_ref", BLOCK_PHOTO),
        ("neutral_Qn", Qn, "HSE06 neutral Qn c_ref", BLOCK_NEUTRAL),
        ("neutral_Q0", Q0, "HSE06 neutral Q0 c_ref", BLOCK_NEUTRAL),
    ]
    for name, coords, tag, block in jobs:
        d = OUT / name
        d.mkdir(parents=True, exist_ok=True)
        write_poscar(d / "POSCAR", coords, tag)
        (d / "INCAR").write_bytes(incar(tag, block).encode("ascii"))
        (d / "KPOINTS").write_bytes(KPOINTS.encode("ascii"))
    (OUT / "run_chain_fast.sh").write_bytes(CHAIN.encode("utf-8"))
    (OUT / "run.slurm").write_bytes(SLURM.encode("ascii"))
    # verify FERWE count
    s = (OUT / "photo_Qn" / "INCAR").read_text()
    import re
    m = re.search(r"FERWE\s*=\s*([^\n]+)", s)
    n = sum(int(t.split("*")[0]) if "*" in t else 1 for t in m.group(1).split())
    print("photo FERWE entries:", n, "expect", NBANDS * N_K, "OK" if n == NBANDS * N_K else "BAD")
    print("written", OUT)


if __name__ == "__main__":
    main()
