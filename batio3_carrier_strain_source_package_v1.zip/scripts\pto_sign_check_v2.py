#!/usr/bin/env python3
"""PTO PbTiO3 three-term with Q0 from sigma_Q0.txt."""
import re
from pathlib import Path

base = Path("/public/home/scnk2habog/pto_n010")

def sz(p):
    last = None
    for ln in p.read_text(errors="replace").splitlines():
        if "in kB" in ln:
            last = ln
    return float(re.findall(r"[-+]?[0-9]*\.[0-9]+", last.split("kB", 1)[1])[2])

sig = {
    "photo_p": sz(base / "OUTCAR_photo_p003"),
    "photo_m": sz(base / "OUTCAR_photo_m003"),
    "neut_p": sz(base / "OUTCAR_neutral_p003"),
    "neut_m": sz(base / "OUTCAR_neutral_m003"),
    "Q0": sz(base / "sigma_Q0.txt"),
}
lat = (base / "CONTCAR_neutral").read_text().splitlines()
a = float(lat[2].split()[0])
c = float(lat[4].split()[2])
V0 = a * a * c
BF = V0 * 6.241509e-4
print("V0=%.4f A^3 (8 f.u. cell)  a=%.4f c=%.4f" % (V0, a, c))
print("sigma_zz kbar:", sig)
bp = -BF * (sig["photo_p"] + sig["photo_m"]) / 2
bn = -BF * (sig["neut_p"] + sig["neut_m"]) / 2
b0 = -BF * sig["Q0"]
d, m = bp - bn, bn - b0
print("b_photo=%+.5f  b_neutral(Qn)=%+.5f  b_Q0=%+.5f  eV/strain/cell" % (bp, bn, b0))
print("direct  = %+.5f eV/strain/cell   (%+.5f per f.u.)" % (d, d / 8))
print("mediated= %+.5f eV/strain/cell   (%+.5f per f.u.)" % (m, m / 8))
print("net     = %+.5f eV/strain/cell" % (d + m))
if d < 0 and m > 0 and abs(m) > abs(d):
    print("SIGN: MATCHES BaTiO3  (direct<0, mediated>0, |med|>|direct|)")
elif d < 0 and m > 0:
    print("SIGN: direct<0 mediated>0 (|med| not larger)")
else:
    print("SIGN: CHECK  direct=%+.4f mediated=%+.4f" % (d, m))
