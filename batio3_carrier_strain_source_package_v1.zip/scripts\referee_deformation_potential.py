# -*- coding: utf-8 -*-
"""Band-resolved deformation potentials from the B matched stencils (n=0.10).

For each of the four +-0.3% c statics (photo/neutral), extract the final
eigenvalue table from OUTCAR and compute per-k edge slopes

    dE_edge/deta = [E_edge(+eta) - E_edge(-eta)] / (2 * 0.003)

Report: VBM/CBM slopes, gap deformation potential, and the
occupation-weighted edge sum (the band-slope language of the direct channel).
Purpose: quantitative mechanism anchor for Fig. 5 / the mechanism paragraph:
the expansion-favouring direct term is the occupation-weighted band-edge
response to c strain, and the CBM slope is its dominant piece.

Note: eigenvalue slopes are a mechanism diagnostic; they do not by themselves
reconstruct the full stress (Pulay/charge-response terms are not in the band
sum), so the writeup states consistency, not an exact decomposition.
"""
from pathlib import Path
import re
import sys

BASE = Path(r"C:\Users\GM\Desktop\work\batio3_c642_campaign\B_stencil_out")
ETA = 0.003

FILES = {
    ("photo", "+"): BASE / "OUTCAR_photo_p003",
    ("photo", "-"): BASE / "OUTCAR_photo_m003",
    ("neutral", "+"): BASE / "OUTCAR_neutral_p003",
    ("neutral", "-"): BASE / "OUTCAR_neutral_m003",
}


def parse_last_eigenvalues(path):
    """Return list of (weight, [(band, energy, occ), ...]) per k-point.

    VASP 6 OUTCAR k-lines look like
        k-point    40 :       0.5000    0.5000    0.5000
    (no weight column); equal weights are used for the report averages.
    """
    text = Path(path).read_text(errors="replace")
    head_re = re.compile(
        r"k-point\s+(\d+)\s*:\s*([-+0-9.Ee]+)\s+([-+0-9.Ee]+)\s+([-+0-9.Ee]+)"
    )
    marks = list(head_re.finditer(text))
    out = []
    for j, m in enumerate(marks):
        blk_start = m.end()
        blk_end = marks[j + 1].start() if j + 1 < len(marks) else len(text)
        bands = []
        for ln in text[blk_start:blk_end].splitlines():
            parts = ln.split()
            if len(parts) >= 3:
                try:
                    bands.append((int(parts[0]), float(parts[1]), float(parts[2])))
                except ValueError:
                    continue
        if len(bands) >= 150:
            out.append((1.0, bands))
    return out


def edges(bands):
    """VBM (max energy with occ >= 1.0) and CBM (min energy with occ < 1.0)."""
    occ_band = [b for b in bands if b[2] >= 1.0]
    emp_band = [b for b in bands if b[2] < 1.0]
    if not occ_band or not emp_band:
        raise RuntimeError("no occupied/empty split")
    vbm = max(occ_band, key=lambda b: b[1])
    cbm = min(emp_band, key=lambda b: b[1])
    return vbm[1], cbm[1]


def load_edges(path):
    kdata = parse_last_eigenvalues(path)
    res = []
    for w, bands in kdata:
        ev, ec = edges(bands)
        res.append((w, ev, ec))
    return res


def main():
    data = {k: load_edges(p) for k, p in FILES.items()}
    nk = {k: len(v) for k, v in data.items()}
    print("k-points per file:", nk)
    assert len(set(nk.values())) == 1, "k-point counts differ between stencils"
    n = nk[("photo", "+")]

    results = {}
    for species in ("photo", "neutral"):
        wp, ep, cp = zip(*data[(species, "+")])
        wm, em, cm = zip(*data[(species, "-")])
        wsum = sum(wp)
        dev = [(ep[i] - em[i]) / (2 * ETA) for i in range(n)]
        dec = [(cp[i] - cm[i]) / (2 * ETA) for i in range(n)]
        dev_avg = sum(wp[i] * dev[i] for i in range(n)) / wsum
        dec_avg = sum(wm[i] * dec[i] for i in range(n)) / wsum
        # gap slope
        dgap = [dec[i] - dev[i] for i in range(n)]
        dgap_avg = sum(wp[i] * dgap[i] for i in range(n)) / wsum
        # weighted occupied-edge sum at eta=0 (midpoint of +- stencils)
        # occ: neutral VBM=2, CBM=0; photo VBM=1.2, CBM=0.8 (uniform n=0.10)
        occ_v, occ_c = (1.2, 0.8) if species == "photo" else (2.0, 0.0)
        bandsum = sum(
            wp[i] * (occ_v * (ep[i] + em[i]) / 2 + occ_c * (cp[i] + cm[i]) / 2)
            for i in range(n)
        ) / wsum
        bandsum_slope = sum(
            wp[i] * (occ_v * dev[i] + occ_c * dec[i]) for i in range(n)
        ) / wsum
        results[species] = dict(dev=dev_avg, dec=dec_avg, dgap=dgap_avg,
                                bandsum_slope=bandsum_slope,
                                dec_per_k=dec, dev_per_k=dev, dgap_per_k=dgap,
                                vbm=sum(ep[i] * wp[i] for i in range(n)) / wsum,
                                cbm=sum(cp[i] * wp[i] for i in range(n)) / wsum)

    print()
    print("Band-resolved deformation potentials (eV per unit strain), n=0.10 stencils")
    print("%-9s %12s %12s %12s %16s" % ("species", "dEv/deta", "dEc/deta", "dEgap/deta", "occ-weighted sum"))
    for sp in ("neutral", "photo"):
        r = results[sp]
        print("%-9s %12.3f %12.3f %12.3f %16.3f"
              % (sp, r["dev"], r["dec"], r["dgap"], r["bandsum_slope"]))
    print()
    d_ev = results["photo"]["dev"] - results["neutral"]["dev"]
    d_ec = results["photo"]["dec"] - results["neutral"]["dec"]
    d_bs = results["photo"]["bandsum_slope"] - results["neutral"]["bandsum_slope"]
    print("photo - neutral:")
    print("  d(dEv/deta)   = %+.3f" % d_ev)
    print("  d(dEc/deta)   = %+.3f" % d_ec)
    print("  d(occ-sum)    = %+.3f   (band-slope language of the direct channel)" % d_bs)
    print()
    if results["photo"]["dec"] < results["photo"]["dev"]:
        print("CBM slope steeper than VBM slope (photo): conduction edge dominates the strain response")
    # direct term (B triple) = -2.493 eV/strain/8fu at n=0.10
    # occ-sum change is the same quantity in band-slope language
    direct_ref = -2.493
    print("direct-channel cross-check: d(occ-sum)=%.3f vs B-triple direct=%.3f eV/strain"
          % (d_bs, direct_ref))
    print("  ratio = %.3f   |residual| = %.3f eV/strain"
          % (d_bs / direct_ref, abs(d_bs - direct_ref)))
    print("sign: d(occ-sum) < 0 means carrier transfer steepens the expansion-favouring "
          "band-energy slope, matching the negative direct term.")
    print()
    dec_p = results["photo"]["dec_per_k"]
    dgap_p = results["photo"]["dgap_per_k"]
    print("per-k dEc/deta (photo) min/max: %.3f / %.3f" % (min(dec_p), max(dec_p)))
    print("per-k dEgap/deta (photo) min/max: %.3f / %.3f" % (min(dgap_p), max(dgap_p)))


if __name__ == "__main__":
    main()
