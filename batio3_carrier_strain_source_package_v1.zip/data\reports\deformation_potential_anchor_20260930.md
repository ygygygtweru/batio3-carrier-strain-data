# 形变势机制锚（Fig.5 / 机制段落数字）
日期：2026-09-30 · 脚本：`tools/referee_deformation_potential.py` · 数据：`batio3_c642_campaign/B_stencil_out`（n=0.10 ±0.3% c 四点）

## 主结果（eV per unit strain）

| species  | dEv/dη | dEc/dη | dEgap/dη | occ-weighted sum |
|----------|--------|--------|----------|------------------|
| neutral  | −6.763 | −9.878 | −3.115   | −13.526          |
| photo    | −6.766 | −9.909 | −3.143   | −16.046          |

photo − neutral：

- d(dEv/dη) = **−0.003**（VBM 斜率几乎不变）
- d(dEc/dη) = **−0.031**（CBM 略变陡）
- d(occ-sum) = **−2.521** ← 这就是 direct 通道的能带语言

## 与 B 三项交叉核对（同 n=0.10）

| 来源 | direct (eV/strain) | 备注 |
|------|-------------------|------|
| B 应力三项分解 | **−2.493** | referee_b_triple.py |
| 能带占据加权斜率差 | **−2.521** | 本分析 |
| 残差 | 0.028（比值 1.011） | ~1% 一致 |

**结论（可写进机制段）**：direct 通道 = 转移占据量 × 带隙形变势，到 1% 精度闭合。
n=0.10 时 CBM 占据 0.8，dEgap/dη ≈ −3.12，0.8 × (−3.12) ≈ −2.50 ≈ direct = −2.493。
CBM 斜率（−9.88）比 VBM（−6.76）更陡，导带边主导应变响应；占据从 VBM 迁到 CBM 后，
体系在拉伸 c 方向上能量降得更快 → 膨胀倾向（与负 direct 同号）。

## 逐 k 散布（photo）

- dEc/dη：−12.12 … −8.05
- dEgap/dη：−5.87 … −1.88（全部为负 → 带隙在拉伸下收窄，各 k 一致）

## 论文写法建议（防防御）

> The direct channel is the occupation-weighted band-edge slope: transferring
> 0.8 electrons from the valence to the conduction edge multiplies the gap
> deformation potential (−3.1 eV per unit strain) into a −2.5 eV/strain
> contribution, closing against the stress-based direct term (−2.49) at the
> percent level. The conduction edge carries the steeper slope (−9.9 vs −6.8),
> so the expansion-favouring drive is conduction-edge dominated.

注意：本分析是机制诊断，不是全应力的精确分解（Pulay/电荷响应不在能带和内）。
措辞用 "closes against / consistent at the percent level"，不要写 "proves exact decomposition"。

## A 组 Δc/c 终值更新（HSS 实测）

| 点 | n | c (Å) | σ (kbar) | Δc/c | 状态 |
|----|---|-------|----------|------|------|
| A0n | 0 | 8.139726 | — | 0 (ref) | FINAL（VASP 6.4.2 复核一致） |
| A1 | 0.05 | 8.11327 | 0.628 → 收敛中 | **−0.325%**（会略升） | RUNNING job 10071 |
| A2 | 0.10 | **8.07792** | **0.497** | **−0.759%** | **FINAL**（LOOP_DONE） |
| A3 | 0.15 | 8.02979 | — | **−1.351%** | FINAL |

A2 终值与此前外推 −0.76% 吻合；A1 预计落点 −0.32% 附近。
