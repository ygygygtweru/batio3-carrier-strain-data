# 符号结构交叉验证汇总（2026-10-01）· FINAL
direct < 0 · mediated > 0 · |mediated| > |direct| · net > 0

## 0. A 组 Δc/c FINAL（HSS，LOOP_DONE 全员）

| 点 | n | c (Å) | σ_zz (kbar) | Δc/c |
|----|---|-------|-------------|------|
| A0n | 0 | 8.139726 | — | 0 (ref) |
| A1 | 0.05 | **8.113992** | 0.446 | **−0.316%** |
| A2 | 0.10 | **8.077920** | 0.497 | **−0.759%** |
| A3 | 0.15 | **8.029786** | — | **−1.351%** |

单调收缩，随 n 加深。A1/A2 与此前外推 −0.33/−0.76 一致。

## 1. HSE06 五原子 BaTiO₃（job 10471/10472/10473，~8 min/静态）

| 量 | σ_zz (kbar) | b (eV/strain/f.u.) |
|----|-------------|---------------------|
| photo Qn | +28.237 | −1.116 |
| neutral Qn | +14.836 | −0.586 |
| neutral Q0 | +47.951 | −1.895 |

- **direct = −0.529** eV/strain/f.u.
- **mediated = +1.308** eV/strain/f.u.
- net = +0.779
- **SIGN MATCH**（占据门禁 PASS 1.9/0.1）

协议：4×4×4 ISYM=0（N_k=64）、NKRED=2、ISIF=2、HSE06、n=0.10 FERWE。
幅值不与 PBE 比（protocol-dependent），只验符号。

## 2. PTO PbTiO₃ 40 原子（cancon 123389478 + Q0 123415285）

| 量 | σ_zz (kbar) | b (eV/strain/cell) |
|----|-------------|---------------------|
| photo +0.3% | −2.965 | |
| photo −0.3% | +13.662 | mean → −1.673 |
| neutral +0.3% | −6.778 | |
| neutral −0.3% | +10.024 | mean → −0.508 |
| neutral Q0 | +6.831 | −2.136 |

- **direct = −1.165** eV/strain/cell（**−0.146 / f.u.**）
- **mediated = +1.628** eV/strain/cell（**+0.204 / f.u.**）
- net = +0.463 /cell
- **SIGN MATCH**（第二材料迁移成立）

## 3. BaTiO₃ PBE B 三项（参考）

direct = −2.493 · mediated = +14.013 · net = +11.521 eV/strain/8fu

## 4. 形变势闭合（同 PBE）

d(occ-sum) = −2.521 vs direct = −2.493（残差 0.028）

## 结论（可入正文/SI）

> The sign structure (direct &lt; 0, mediated &gt; 0, |mediated| dominating) survives
> (i) the HSE06 hybrid on the five-atom cell and (ii) transfer to PbTiO3,
> while the magnitudes remain protocol-dependent as stated.

表格一行建议：
| Protocol | direct | mediated | net | sign |
|----------|--------|----------|-----|------|
| PBE 64-atom BaTiO3 | −2.49 | +14.01 | +11.52 | ✓ |
| HSE06 5-atom BaTiO3 | −0.53 | +1.31 | +0.78 | ✓ |
| PBE 40-atom PbTiO3 | −0.15/f.u. | +0.20/f.u. | +0.06/f.u. | ✓ |
