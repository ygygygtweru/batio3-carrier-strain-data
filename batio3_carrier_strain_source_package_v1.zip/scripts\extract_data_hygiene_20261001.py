#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Data hygiene: extract Qn/Q0 lattice + polar proxy + loop traces + PTO finals.

No new DFT. Read-only from existing CONTCAR/loop_trace/OUTCAR.
"""
from pathlib import Path
import re

OUT = Path(r"C:\Users\GM\Desktop\work\npj_batio3_writing\deliverables\data_hygiene_extract_20261001.md")
lines = []


def say(s=""):
    lines.append(s)


def read_poscar(path):
    ls = Path(path).read_text(errors="replace").splitlines()
    a = float(ls[2].split()[0])
    c = float(ls[4].split()[2])
    # first Ba, first Ti z (Direct)
    # find 'Direct' then first 8 Ba, next 8 Ti
    i = next(i for i, l in enumerate(ls) if l.strip().lower().startswith("direct"))
    coords = []
    for l in ls[i + 1:]:
        p = l.split()
        if len(p) >= 3:
            try:
                coords.append((float(p[0]), float(p[1]), float(p[2])))
            except ValueError:
                break
        elif coords:
            break
    zBa = coords[0][2] if coords else None
    zTi = coords[8][2] if len(coords) > 8 else None
    return dict(a=a, c=c, zBa=zBa, zTi=zTi, n=len(coords), lines=ls[:8])


def polar_proxy(zBa, zTi):
    """Prim-cell Ti-Ba z separation (frac), for 2x2x2 supercell."""
    if zBa is None or zTi is None:
        return None
    return round(((zTi - zBa) * 2) % 1.0, 8)


say("# Data hygiene extract (2026-10-01)")
say("Read-only from existing CONTCAR / loop_trace. No new VASP.")
say("")

# --- A group loop traces ---
say("## 1. A1–A3 loop traces (c-loop until |sigma_zz| <= 0.5 kbar)")
say("")
for tag, p in [
    ("A1 n=0.05", Path(r"C:\Users\GM\Desktop\work\batio3_npj_A_stage_hss\A1_photo_n005\loop_trace.txt")),
    ("A2 n=0.10", Path(r"C:\Users\GM\Desktop\work\batio3_npj_A_stage_hss\A2_photo_n010\loop_trace.txt")),
    ("A3 n=0.15", Path(r"C:\Users\GM\Desktop\work\batio3_A_stage_c642\A3_photo_n015\loop_trace.txt")),
]:
    say(f"### {tag}")
    if p.exists():
        say("```")
        say(p.read_text().rstrip())
        say("```")
    else:
        say("(missing)")
    say("")

# --- lattices ---
say("## 2. Final / reference lattices and polar proxy")
say("")
say("| structure | source | a (Å) | c (Å) | z_Ba | z_Ti | Ti−Ba (prim z) |")
say("|-----------|--------|-------|-------|------|------|----------------|")
rows = []
for tag, p in [
    ("A0n Q0 c0", Path(r"C:\Users\GM\Desktop\work\batio3_q0ref_B\POSCAR")),  # actually A0_neutral_c at c_ref
    ("A1 CONTCAR", Path(r"C:\Users\GM\Desktop\work\batio3_npj_A_stage_hss\A1_photo_n005\CONTCAR")),
    ("A2 CONTCAR", Path(r"C:\Users\GM\Desktop\work\batio3_npj_A_stage_hss\A2_photo_n010\CONTCAR")),
    ("B Qn (edge-state photo)", Path(r"C:\Users\GM\Desktop\work\batio3_npj_BC_stage\B_er_n010_stage2_photo\POSCAR")),
    ("Q0ref_B (neutral@Q0, c_ref)", Path(r"C:\Users\GM\Desktop\work\batio3_q0ref_B\POSCAR")),
]:
    if not p.exists():
        rows.append(f"| {tag} | {p.name} | MISSING | | | | |")
        continue
    d = read_poscar(p)
    pq = polar_proxy(d["zBa"], d["zTi"])
    rows.append(f"| {tag} | {p.parent.name} | {d['a']:.7f} | {d['c']:.7f} | {d['zBa']:.8f} | {d['zTi']:.8f} | {pq} |")
for r in rows:
    say(r)
say("")
say("Note: q0ref_B POSCAR is titled A0_neutral_c at c=8.029786 (Q0 ions at the B working cell),")
say("not the A0n c0=8.139726 neutral reference.")
say("")
say("A1/A2 CONTCAR lattices (from HSS, remote head):")
say("- A1: a=7.9414348, c=8.113991521  (final, LOOP_DONE)")
say("- A2: a=7.9414348, c=8.077920249  (final, LOOP_DONE)")
say("")
say("### SCAN check (cancon) — Qn / Q0")
say("")
say("| structure | source (cancon) | a | c | z_Ba | z_Ti | Ti−Ba |")
say("|-----------|-----------------|---|---|------|------|-------|")
say("| SCAN Qn (C_scan_n010/CONTCAR) | batio3_npj_BC_stage/C_scan_n010 | 7.9414348 | **8.053875** | 0.25650575 | 0.01430583 | 0.51560 |")
say("| SCAN Q0 (q0ref_C/CONTCAR) | batio3_q0ref_C | 7.9414348 | 8.029786 | 0.25804250 | 0.01652450 | 0.51697 |")
say("")
say("### SCAN check geometry identity — RESOLVED")
say("")
say("Production SCAN numbers in the paper come from local `batio3_c642_campaign/C_photo_out`,")
say("whose stencils are CORRECT:")
say("")
say("| file | A3 c (Å) | expected | verdict |")
say("|------|----------|----------|---------|")
say("| OUTCAR_photo_m003 | 8.0056966784 | 8.029786*0.997 | ✓ |")
say("| OUTCAR_photo_p003 | 8.0538753946 | 8.029786*1.003 | ✓ |")
say("| OUTCAR_neutral_at_Qn | 8.0297860365 | c_ref | ✓ |")
say("| OUTCAR_neutral_Q0_scan | 8.1397261575 | c0 (A0n) | see note |")
say("")
say("Real SCAN Qn ions (c=8.029786): cancon `C_scan_n010/CONTCAR_photo`,")
say("Ba z=0.25650575, Ti z=0.01430583, Ti−Ba=0.51560.")
say("SCAN Q0 at the working cell: `batio3_q0ref_C` (c=8.029786), Ti−Ba=0.51697.")
say("")
say("The file `C_scan_n010/CONTCAR` at c=8.053875 is a leftover from a BROKEN re-run")
say("on cancon (scale_c applied to an already-scaled CONTCAR). That chain would have")
say("produced m003 at 8.029714 instead of 8.005697. Do not use cancon C_scan_n010/CONTCAR")
say("as Qn and do not reuse run_chain_C.sh as written. The paper numbers are from the")
say("local C_photo_out set and are unaffected.")
say("")
say("Note: OUTCAR_neutral_Q0_scan is at c0=8.1397, not c_ref. The mediated term must")
say("use the Q0 static at c_ref (the 123378168 job / batio3_q0ref_C), which exists.")
say("")
say("### A3 CONTCAR anomaly — SOURCE IDENTIFIED")
say("")
say("A3 POSCAR.start already contains the same [111]-type coordinates (Ba/Ti x=y=z).")
say("This is not mid-run corruption; the n=0.15 joint-relax job was started from a")
say("different internal-coordinate setting than A1/A2. Before treating -1.35% as a")
say("validated P4mm endpoint, trace where POSCAR.start was generated. The c value is")
say("consistent; the internal coordinates are not comparable to A1/A2 without that")
say("lineage check. Table S2 n=0.15 fixed-cell data is a separate calculation set.")

# --- polar-mode Qn vs Q0 at same c ---
q0 = read_poscar(Path(r"C:\Users\GM\Desktop\work\batio3_q0ref_B\POSCAR"))
qn = read_poscar(Path(r"C:\Users\GM\Desktop\work\batio3_npj_BC_stage\B_er_n010_stage2_photo\POSCAR"))
pq0 = polar_proxy(q0["zBa"], q0["zTi"])
pqn = polar_proxy(qn["zBa"], qn["zTi"])
say("## 3. Polar proxy at B working cell (c=8.029786)")
say("")
say(f"- Q0 (neutral ions): Ti−Ba = {pq0}")
say(f"- Qn (edge-state photo ions): Ti−Ba = {pqn}")
if pq0 and pqn:
    say(f"- Δ(Q0−Qn) = {round(pq0 - pqn, 6)}  (carrier reduces polar offset)")
say("")

# --- HSE / PTO finals (from prior extract, restate) ---
say("## 4. HSE06 five-atom finals (already in sign_structure_crosscheck)")
say("- photo_Qn / neutral_Qn / neutral_Q0 sigma_zz = 28.237 / 14.836 / 47.951 kbar")
say("- three-term per f.u.: direct −0.529, mediated +1.308, net +0.779")
say("")
say("## 5. PTO PbTiO3 finals (from cancon pto_n010)")
say("- clamped cell: a=b=7.724785906 Å, c=8.395959065 Å (eps_par = −0.405% vs bulk)")
say("- CONTCAR_neutral and CONTCAR_photo share this cell (ISIF=2 ion relax)")
say("- Q0 stress (neutral@Q0, c_ref): sigma_zz = 6.831 kbar")
say("- stencils sigma_zz: photo ±0.3% = −2.965 / +13.662; neutral ±0.3% = −6.778 / +10.024")
say("- three-term per 8 f.u.: direct −1.165, mediated +1.628, net +0.463")
say("")

OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
print("\nWROTE", OUT)
