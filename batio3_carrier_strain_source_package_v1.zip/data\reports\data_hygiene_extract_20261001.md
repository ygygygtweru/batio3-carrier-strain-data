# Data hygiene extract (2026-10-01)
Read-only from existing CONTCAR / loop_trace. No new VASP.

## 1. A1–A3 loop traces (c-loop until |sigma_zz| <= 0.5 kbar)

### A1 n=0.05
```
1 8.029786036462555 15.99062
2 8.059786036462555 10.02349
3 8.088645097068616 4.73701
4 8.101484521311040 2.45574
5 8.107411006159525 1.53211
6 8.110538612220131 1.09380
1 8.1123380061595238 0.80874
2 8.113273581917099 0.62844
3 8.113662794038310 0.55861
4 8.113840400098917 0.52717
5 8.113922733432251 0.51263
6 8.113961006159522 0.50614
7 8.113979612220129 0.50299
8 8.113988672826190 0.50094
9 8.113991521311039 0.44639
```

### A2 n=0.10
```
1 8.029786036462555 8.60215
2 8.054338006159526 4.39198
3 8.066131884947405 2.36465
4 8.071782339492859 1.49177
5 8.074787703129223 1.01994
6 8.076363278886799 0.77350
7 8.077192066765587 0.63677
8 8.077606521311042 0.57044
9 8.077819975856496 0.53309
1 8.0778199758564959 0.53309
2 8.077920248583769 0.49745
```

### A3 n=0.15
```
1 8.029786036462555 -0.38201
```

## 2. Final / reference lattices and polar proxy

| structure | source | a (Å) | c (Å) | z_Ba | z_Ti | Ti−Ba (prim z) |
|-----------|--------|-------|-------|------|------|----------------|
| A0n Q0 c0 | batio3_q0ref_B | 7.9414348 | 8.0297860 | 0.25815968 | 0.01638809 | 0.51645682 |
| A1 CONTCAR | CONTCAR | MISSING | | | | |
| A2 CONTCAR | CONTCAR | MISSING | | | | |
| B Qn (edge-state photo) | B_er_n010_stage2_photo | 7.9414348 | 8.0297860 | 0.25535874 | 0.01024727 | 0.50977707 |
| Q0ref_B (neutral@Q0, c_ref) | batio3_q0ref_B | 7.9414348 | 8.0297860 | 0.25815968 | 0.01638809 | 0.51645682 |

Note: q0ref_B POSCAR is titled A0_neutral_c at c=8.029786 (Q0 ions at the B working cell),
not the A0n c0=8.139726 neutral reference.

A1/A2 CONTCAR lattices (from HSS, remote head):
- A1: a=7.9414348, c=8.113991521  (final, LOOP_DONE)
- A2: a=7.9414348, c=8.077920249  (final, LOOP_DONE)

### SCAN check (cancon) — Qn / Q0

| structure | source (cancon) | a | c | z_Ba | z_Ti | Ti−Ba |
|-----------|-----------------|---|---|------|------|-------|
| SCAN Qn (C_scan_n010/CONTCAR) | batio3_npj_BC_stage/C_scan_n010 | 7.9414348 | **8.053875** | 0.25650575 | 0.01430583 | 0.51560 |
| SCAN Q0 (q0ref_C/CONTCAR) | batio3_q0ref_C | 7.9414348 | 8.029786 | 0.25804250 | 0.01652450 | 0.51697 |

### SCAN check geometry identity — RESOLVED

Production SCAN numbers in the paper come from local `batio3_c642_campaign/C_photo_out`,
whose stencils are CORRECT:

| file | A3 c (Å) | expected | verdict |
|------|----------|----------|---------|
| OUTCAR_photo_m003 | 8.0056966784 | 8.029786*0.997 | ✓ |
| OUTCAR_photo_p003 | 8.0538753946 | 8.029786*1.003 | ✓ |
| OUTCAR_neutral_at_Qn | 8.0297860365 | c_ref | ✓ |
| OUTCAR_neutral_Q0_scan | 8.1397261575 | c0 (A0n) | see note |

Real SCAN Qn ions (c=8.029786): cancon `C_scan_n010/CONTCAR_photo`,
Ba z=0.25650575, Ti z=0.01430583, Ti−Ba=0.51560.
SCAN Q0 at the working cell: `batio3_q0ref_C` (c=8.029786), Ti−Ba=0.51697.

The file `C_scan_n010/CONTCAR` at c=8.053875 is a leftover from a BROKEN re-run
on cancon (scale_c applied to an already-scaled CONTCAR). That chain would have
produced m003 at 8.029714 instead of 8.005697. Do not use cancon C_scan_n010/CONTCAR
as Qn and do not reuse run_chain_C.sh as written. The paper numbers are from the
local C_photo_out set and are unaffected.

Note: OUTCAR_neutral_Q0_scan is at c0=8.1397, not c_ref. The mediated term must
use the Q0 static at c_ref (the 123378168 job / batio3_q0ref_C), which exists.

### A3 CONTCAR anomaly — SOURCE IDENTIFIED

A3 POSCAR.start already contains the same [111]-type coordinates (Ba/Ti x=y=z).
This is not mid-run corruption; the n=0.15 joint-relax job was started from a
different internal-coordinate setting than A1/A2. Before treating -1.35% as a
validated P4mm endpoint, trace where POSCAR.start was generated. The c value is
consistent; the internal coordinates are not comparable to A1/A2 without that
lineage check. Table S2 n=0.15 fixed-cell data is a separate calculation set.
## 3. Polar proxy at B working cell (c=8.029786)

- Q0 (neutral ions): Ti−Ba = 0.51645682
- Qn (edge-state photo ions): Ti−Ba = 0.50977707
- Δ(Q0−Qn) = 0.00668  (carrier reduces polar offset)

## 4. HSE06 five-atom finals (already in sign_structure_crosscheck)
- photo_Qn / neutral_Qn / neutral_Q0 sigma_zz = 28.237 / 14.836 / 47.951 kbar
- three-term per f.u.: direct −0.529, mediated +1.308, net +0.779

## 5. PTO PbTiO3 finals (from cancon pto_n010)
- clamped cell: a=b=7.724785906 Å, c=8.395959065 Å (eps_par = −0.405% vs bulk)
- CONTCAR_neutral and CONTCAR_photo share this cell (ISIF=2 ion relax)
- Q0 stress (neutral@Q0, c_ref): sigma_zz = 6.831 kbar
- stencils sigma_zz: photo ±0.3% = −2.965 / +13.662; neutral ±0.3% = −6.778 / +10.024
- three-term per 8 f.u.: direct −1.165, mediated +1.628, net +0.463

