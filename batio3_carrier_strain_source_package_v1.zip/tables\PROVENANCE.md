# Provenance notes (data hygiene, 2026-10-01)

## Production SCAN stencils
Source: batio3_c642_campaign/C_photo_out
- OUTCAR_photo_m003 c = 8.0056966784 = cref*0.997  OK
- OUTCAR_photo_p003 c = 8.0538753946 = cref*1.003  OK
- OUTCAR_neutral_at_Qn c = 8.0297860365 = cref     OK
- Q0 at working cell: batio3_q0ref_C (job 123378168)

A broken re-run exists on the cluster as C_scan_n010/run_chain_C.sh
(scale_c applied twice; m003 would land at 8.029714). Do not reuse that
script. Paper numbers come from C_photo_out and are unaffected.

## A3 joint-relaxation endpoint
c = 8.029786 is consistent. Starting internal coordinates in POSCAR.start
are a [111]-type offset (Ba/Ti x=y=z), unlike the tetragonal motif of A1/A2.
Treated in the manuscript as an endpoint contraction check only, not as a
verified P4mm-branch member. Table S2 n=0.15 fixed-cell data is separate.

## Volume normalisation
B/SCAN stress conversions use Vref = 7.941434809^2 * 8.029786036 = 506.409592 A^3
(stencil reference cell), not the neutral c0 volume 513.3431 A^3.
