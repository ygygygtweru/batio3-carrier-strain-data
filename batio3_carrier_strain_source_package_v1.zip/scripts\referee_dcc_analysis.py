# -*- coding: utf-8 -*-
"""Referee-computation analysis: measured Delta c/c vs model predictions.

Measured (from HSS/cancon c-loop traces):
    c_photo(n) from final converged c in loop_trace.txt
    c_neutral  from A0n converged c
    dkk(n) = (c_photo - c_neutral) / c_neutral

Model predictions (Table S3 + paper Q_eq path):
    kappa(Q,n) = K0 + KQ*(Q^2-1) + (KN + KNQ*Q^2)*n
    (1) fixed-path:      eta = -dBeff / kappa(Q_eq(n), n)
    (2) coupled (exact): eta from F(Q,eta)=Epolar+b*eta+kappa/2*eta^2
        with Q relaxed:  k_eff = k - b_Q^2 / F_QQ   (Schur complement)
        eta = -dBeff / k_eff,  b_Q = 2*Q*(BQ + BNQ*n),
        F_QQ = 2*(A2+G2*n) + 12*(A4+G4*n)*Q^2   (in eV)
        dBeff = model net Delta b (MODEL_TRIPLET rows for 0.05/0.10/0.15)

Outputs a markdown block; rerun as traces complete.
"""
from pathlib import Path

ROOT = Path(r"C:\Users\GM\Desktop\work")

# --- Table S3 ---
K0, KQ, KN, KNQ = 862.064223, 118.226950, -57.983098, -71.378032   # eV/strain^2/8fu
BQ, BN, BNQ = -16.609271, -27.254102, 1.602587                      # eV/strain/8fu
A4, G2, G4 = 323.899765, 3000.310935, -686.830341                   # meV/8fu
A2 = -647.7995306071548                                              # meV/8fu

# model net Delta b at n = 0.05 / 0.10 / 0.15 (eV/strain/8fu), from MODEL_TRIPLET
DBEFF = {0.05: 1.210, 0.10: 2.928, 0.15: 5.178}
# paper Q_eq path
QEQ = {0.05: 0.927123, 0.10: 0.825421, 0.15: 0.669072}

C_NEUTRAL = 8.139726157527070  # A0n converged (VASP 6.4.2, == cancon 5.4.4 result)


def kappa(q, n):
    return K0 + KQ * (q * q - 1.0) + (KN + KNQ * q * q) * n


def predictions(n):
    q = QEQ[n]
    db = DBEFF[n]
    k_fix = kappa(q, n)
    eta_fix = -db / k_fix
    # coupled: Schur complement
    a2n = (A2 + G2 * n) / 1000.0        # eV
    a4n = (A4 + G4 * n) / 1000.0        # eV
    f_qq = 2 * a2n + 12 * a4n * q * q   # eV
    b_q = 2 * q * (BQ + BNQ * n)        # eV/strain
    k_eff = k_fix - (b_q * b_q) / f_qq
    eta_coup = -db / k_eff
    return eta_fix, eta_coup, k_fix, k_eff


def measured_trace(dirpath):
    p = Path(dirpath) / "loop_trace.txt"
    if not p.exists():
        return None, None
    last = None
    for ln in p.read_text().splitlines():
        parts = ln.split()
        if len(parts) == 3:
            last = parts
    if last is None:
        return None, None
    c_final = float(last[1])
    sig = float(last[2])
    return c_final, sig


JOBS = {
    0.05: ROOT / "batio3_npj_A_stage_hss" / "A1_photo_n005",
    0.10: ROOT / "batio3_npj_A_stage_hss" / "A2_photo_n010",
    0.15: ROOT / "batio3_A_stage_c642" / "A3_photo_n015",
}

print(f"c_neutral = {C_NEUTRAL:.9f}  (A0n, sigma=+0.07868 kbar, |s|<=0.5)")
print()
hdr = ("n", "c_photo", "sigma_last", "dkk_meas%", "kappa_fix", "pred_fix%",
       "k_eff", "pred_coup%", "ratio_meas/fix")
print("%6s %10s %10s %10s %9s %9s %8s %11s %10s" % hdr)
rows = {}
for n, d in JOBS.items():
    c, s = measured_trace(d)
    ef, ec, kf, ke = predictions(n)
    if c is None:
        print("%6.2f %10s %10s %10s %9.1f %9.3f %8.1f %11.3f %10s"
              % (n, "PENDING", "-", "-", kf, 100 * ef, ke, 100 * ec, "-"))
        continue
    dkk = 100.0 * (c - C_NEUTRAL) / C_NEUTRAL
    ratio = dkk / (100 * ef) if ef else float("nan")
    rows[n] = (c, s, dkk)
    print("%6.2f %10.6f %10.4f %10.3f %9.1f %9.3f %8.1f %11.3f %10.2f"
          % (n, c, s, dkk, kf, 100 * ef, ke, 100 * ec, ratio))

print()
for n in sorted(JOBS):
    ef, ec, kf, ke = predictions(n)
    if n in rows:
        c, s, dkk = rows[n]
        tag = "FINAL" if abs(s) <= 0.5 else f"PROV sigma={s:.2f}"
        print(f"n={n:.2f} [{tag}]  measured dkk = {dkk:.3f}% "
              f"| fixed-kappa pred {100*ef:.3f}% | coupled pred {100*ec:.3f}%")
    else:
        print(f"n={n:.2f} [PENDING]  "
              f"| fixed-kappa pred {100*ef:.3f}% | coupled pred {100*ec:.3f}%")
