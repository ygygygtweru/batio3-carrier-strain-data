#!/usr/bin/env python3
"""Energy-ranked FERWE from EIGENVAL for n=0.10 (0.8 electrons / 40-atom cell).

Fixes vs original:
  - header: VASP6 EIGENVAL has preamble lines; real header is "NELECT NK NBANDS"
    (first field >= 100) -- the old heuristic grabbed line 0 (40 40 1 1).
  - units: EIGENVAL/FERWE occupations are HALF (per-spin, 0-1) units here:
    electrons = 2 * sum_k w_k * sum_b occ.  So a 0.8-electron promotion
    transfers d = 0.4 half-units per k (NOT 0.8).
  - output: FERWE.inc = single "FERWE = ..." line for direct INCAR embedding
    (file mode is not read under ISMEAR=-2). Values stay in half-units,
    matching the production pattern (1.0 full / 0.6 / 0.4 / 0.0).
"""
from pathlib import Path

path = Path("EIGENVAL")
lines = path.read_text().splitlines()

header_i = None
for i, ln in enumerate(lines[:12]):
    parts = ln.split()
    if len(parts) == 3:
        try:
            nelec = float(parts[0])
            nk = int(float(parts[1]))
            nb = int(float(parts[2]))
            if nelec >= 100 and nk > 0 and nb > 10:
                header_i = i
                break
        except Exception:
            pass
if header_i is None:
    raise SystemExit("cannot parse EIGENVAL header")
nelec = float(lines[header_i].split()[0])
nk = int(float(lines[header_i].split()[1]))
nb = int(float(lines[header_i].split()[2]))
print("nelect", nelec, "nk", nk, "nb", nb)

idx = header_i + 1
weights = []
ferwe = []
for _ik in range(nk):
    while idx < len(lines) and not lines[idx].strip():
        idx += 1
    kparts = lines[idx].split()
    idx += 1
    try:
        w = float(kparts[3]) if len(kparts) >= 4 else 1.0
    except Exception:
        w = 1.0
    weights.append(w)
    bands = []
    for _b in range(nb):
        parts = lines[idx].split()
        idx += 1
        bands.append((float(parts[1]), float(parts[2])))
    ferwe.append([b[1] for b in bands])

print("weight sum", sum(weights))

d = 0.4  # half-units per k: 2 * sum(w) * d = 0.8 electrons

for ik in range(nk):
    vb_idx = None
    cb_idx = None
    for i in range(nb - 1, -1, -1):
        if ferwe[ik][i] > 0.5:
            vb_idx = i
            break
    for i in range(nb):
        if ferwe[ik][i] < 0.5:
            cb_idx = i
            break
    if vb_idx is None or cb_idx is None:
        raise SystemExit("vb/cb not found ik=%d" % ik)
    take = min(d, ferwe[ik][vb_idx])
    ferwe[ik][vb_idx] -= take
    ferwe[ik][cb_idx] += take

def write_fmt(name, arr):
    vals = []
    for row in arr:
        vals.extend(f"{v:.6f}" for v in row)
    out = []
    for i in range(0, len(vals), 8):
        out.append(" ".join(vals[i:i + 8]))
    Path(name).write_text("\n".join(out) + "\n", encoding="ascii")
    print(name, "lines", len(out), "vals", len(vals))

vals = []
for row in ferwe:
    vals.extend(f"{v:.6f}" for v in row)
Path("FERWE.inc").write_text("FERWE = " + " ".join(vals) + "\n", encoding="ascii")
print("FERWE.inc vals", len(vals))
write_fmt("FERWE", ferwe)

# sanity: transferred electrons and edge pattern of first k
elec = 0.0
for ik in range(nk):
    elec += weights[ik] * sum(ferwe[ik])
print("electron sum (2*w*occ):", 2.0 * elec, "(expect 304.0 -> 0.8 promoted)")
k0 = ferwe[0]
print("k0 band152/153:", k0[151], k0[152], "(expect ~0.6 / ~0.4)")
print("DONE")
