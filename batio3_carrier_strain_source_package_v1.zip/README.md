# Source data — Polar-coordinate relaxation reverses the local carrier-induced strain drive in epitaxially clamped BaTiO3

Deposit-ready package for Zenodo / Materials Cloud.
Licence: CC-BY-4.0 for data and scripts in this archive.
PAW potentials (VASP) and WAVECAR/CHGCAR files are **not** redistributed.

## What is here

| Path | Contents |
|------|----------|
| `tables/` | Curated CSV summaries (recommended starting point) |
| `tables/PROVENANCE.md` | Geometry/volume provenance and known caveats |
| `data/B_edge_state_stencils/` | Four matched ±0.3% OUTCARs (edge-state occupation) |
| `data/C_SCAN_stencils/` | SCAN matched-stencil OUTCARs + Q0 record |
| `data/occupation/` | Energy-ranked FERWE generator and occupation record |
| `data/HSE06_5atom/` | Three fixed-geometry HSE06 stress jobs (INCAR/POSCAR/OSZICAR/σ) |
| `data/reports/` | Deformation-potential and sign-structure analysis reports |
| `structures/` | Reference and carrier-relaxed POSCAR/CONTCAR files |
| `scripts/` | Analysis scripts used to produce the reported quantities |

## Key results at a glance

Joint c-relaxation (clamped a=b=7.9414348 Å):

| n | c (Å) | Δc/c | status |
|---|-------|------|--------|
| 0.05 | 8.113992 | −0.32% | verified 15-step trace |
| 0.10 | 8.077920 | −0.76% | verified 11-step trace |
| 0.15 | 8.029786 | −1.35% | endpoint check only (see PROVENANCE) |

Three-term accounting (eV per strain per 8 f.u. unless noted):

| protocol | direct | mediated | net |
|----------|--------|----------|-----|
| edge-state PBEsol | −2.459 | +13.824 | +11.365 |
| SCAN | −3.021 | +15.942 | +12.921 |
| HSE06 (per f.u.) | −0.529 | +1.308 | +0.779 |
| PbTiO3 PBEsol | −1.165 | +1.628 | +0.463 |

Sign structure: direct &lt; 0, mediated &gt; 0, |mediated| &gt; |direct|.
Magnitudes are protocol- and material-dependent.

## Stress conversion

b = −V_ref · σ_zz, with V_ref = 506.409592 Å³ for the 64-atom stencil
reference cell (a=7.941434809 Å, c=8.029786036 Å).
1 Å³ · 1 kbar = 6.241509×10⁻⁴ eV.

## Reproducing the analysis

```bash
python scripts/referee_dcc_analysis.py      # dC/c vs fixed-coupled estimates
python scripts/referee_b_triple.py          # three-term split from stencils
python scripts/referee_deformation_potential.py  # band-edge slope diagnostic
python scripts/pto_sign_check_v2.py         # PbTiO3 three-term
```

Paths inside the scripts point at the campaign layout; adjust the `BASE`/`ROOT`
constants if you unpack this archive elsewhere.

## Manuscript mapping

- Table S2 / five stencils: `data/B_edge_state_stencils` + training energies in the SI
- Table S13 joint relaxation: `tables/joint_relaxation_dcc.csv` + `tables/loop_trace_A*.txt`
- SCAN / HSE06 / PbTiO3 sign checks: `tables/three_term_summary.csv`, `data/C_SCAN_stencils`, `data/HSE06_5atom`
- Fig. 4 / mechanism: `data/reports/deformation_potential_*`

## Contact

Corresponding author details are provided in the manuscript.
